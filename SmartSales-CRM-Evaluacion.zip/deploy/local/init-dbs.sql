CREATE DATABASE contacts_db;
CREATE DATABASE sales_db;
